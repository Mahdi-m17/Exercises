﻿using System;
using System.Collections.Generic;
using System.IO;

class Student
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string ID { get; set; }
}

class Program
{
    static Dictionary<string, Student> students = new Dictionary<string, Student>();
    static string filePath = @"C:\UNI.txt";

    static void Main()
    {
        LoadData();
        while (true)
        {
            Console.WriteLine("1. Enter student information");
            Console.WriteLine("2. Display student information");
            Console.WriteLine("3. Delete a student");
            Console.WriteLine("4. Exit");
            Console.Write("Choose an option: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    EnterStudentInformation();
                    break;
                case 2:
                    DisplayStudentInformation();
                    break;
                case 3:
                    DeleteStudent();
                    break;
                case 4:
                    SaveData();
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    static void EnterStudentInformation()
    {
        Student student = new Student();
        Console.Write("Enter student ID: ");
        student.ID = Console.ReadLine();
        Console.Write("Enter student name: ");
        student.Name = Console.ReadLine();
        Console.Write("Enter student age: ");
        student.Age = int.Parse(Console.ReadLine());

        students[student.ID] = student;
        Console.WriteLine("Student information entered successfully.");
    }

    static void DisplayStudentInformation()
    {
        Console.Write("Enter student ID to display: ");
        string id = Console.ReadLine();

        if (students.ContainsKey(id))
        {
            Student student = students[id];
            Console.WriteLine($"ID: {student.ID}, Name: {student.Name}, Age: {student.Age}");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    static void DeleteStudent()
    {
        Console.Write("Enter student ID to delete: ");
        string id = Console.ReadLine();

        if (students.ContainsKey(id))
        {
            students.Remove(id);
            Console.WriteLine("Student deleted successfully.");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    static void SaveData()
    {
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            foreach (var student in students.Values)
            {
                writer.WriteLine($"{student.ID},{student.Name},{student.Age}");
            }
        }
        Console.WriteLine("Data saved successfully.");
    }

    static void LoadData()
    {
        if (File.Exists(filePath))
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    Student student = new Student
                    {
                        ID = parts[0],
                        Name = parts[1],
                        Age = int.Parse(parts[2])
                    };
                    students[student.ID] = student;
                }
            }
        }
    }
}

