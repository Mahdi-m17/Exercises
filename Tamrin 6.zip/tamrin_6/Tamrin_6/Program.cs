﻿using System;
using System.Collections.Generic;

class Student
{
    public string Name { get; set; }
    public int ID { get; set; }
}

class StudentManager
{
    private Dictionary<int, Student> students = new Dictionary<int, Student>();

    public void AddStudent(int id, string name)
    {
        if (!students.ContainsKey(id))
        {
            students[id] = new Student { ID = id, Name = name };
            Console.WriteLine("Student added successfully.");
        }
        else
        {
            Console.WriteLine("Student ID already exists.");
        }
    }

    public void DisplayStudent(int id)
    {
        if (students.ContainsKey(id))
        {
            Console.WriteLine($"Student ID: {students[id].ID}, Name: {students[id].Name}");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }

    public void RemoveStudent(int id)
    {
        if (students.Remove(id))
        {
            Console.WriteLine("Student removed successfully.");
        }
        else
        {
            Console.WriteLine("Student not found.");
        }
    }
}

class Program
{
    static void Main()
    {
        StudentManager manager = new StudentManager();
        while (true)
        {
            Console.WriteLine("\n1. Enter Student Information\n2. Display Student Information\n3. Remove a Student\n4. Exit");
            Console.Write("Choose an option: ");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter Student ID: ");
                    int id = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Student Name: ");
                    string name = Console.ReadLine();
                    manager.AddStudent(id, name);
                    break;
                case 2:
                    Console.Write("Enter Student ID: ");
                    int displayId = Convert.ToInt32(Console.ReadLine());
                    manager.DisplayStudent(displayId);
                    break;
                case 3:
                    Console.Write("Enter Student ID: ");
                    int removeId = Convert.ToInt32(Console.ReadLine());
                    manager.RemoveStudent(removeId);
                    break;
                case 4:
                    return;
                default:
                    Console.WriteLine("Invalid choice. Try again.");
                    break;
            }
        }
    }
}

